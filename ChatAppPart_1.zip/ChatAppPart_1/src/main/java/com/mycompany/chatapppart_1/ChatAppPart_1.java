/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppart_1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ChatAppPart_1 
{

    public static void main(String[] args) 
    {
         // introducing the scanner to allow the user to inpute details
    
    Scanner input = new Scanner(System.in);
     
    // creating an object
    
    Login login = new Login();
    
    // Allowing the user to register 
    
    System.out.println("=== USER REGISTRATION ===");
    
    // user to input his or her username and processing it
    
    System.out.print("Enter a username:");
    String username = input.nextLine();
    
    // user to input his or her password and processing it
    
    System.out.print("Enter a password:");
    String password = input.nextLine();
    
    // User to input his or her South African number
    
    System.out.print("Enter your South African phone number(+27...): ");
    String phone = input.nextLine();
    
    // Storing the registerd details 
    
    String response = login.registerUser(username, password, phone);
    
    // Dispalying the registration message
    
    System.out.println(response);
    
    
    // Enebling the user to login
    
    System.out.println("\n=== User LOGIN ===");
    
    // user to login usesing his/her username
    
    System.out.print("Enter your username: ");
    String loginUsername = input.nextLine();
    
    // user to login by entering his/her password
    
    System.out.print("Enter your password: ");
    String loginPassword = input.nextLine();
    
    // introducing loginuser to check if the deatails are correct
    
    boolean loggedIn = login.LoginUser(loginUsername,loginPassword);
    
    // Printing out the logged in message
    
    String loginMessage = login.returnloginStatus(loggedIn);
    System.out.println(loginMessage);
    }
}
